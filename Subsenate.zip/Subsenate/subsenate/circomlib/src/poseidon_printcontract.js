const poseidonGenContract = require("./poseidon_gencontract");


console.log(poseidonGenContract.createCode(6, 8, 57));

