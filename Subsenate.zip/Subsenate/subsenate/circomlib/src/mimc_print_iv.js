const mimc7 = require("./mimc7.js");

console.log("IV: "+mimc7.getIV().toString());
